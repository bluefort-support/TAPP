﻿
$blockListedPackage = (
"dynamicsax-appfoundationtestcommon",
"dynamicsax-appfoundationtestcommon-compile",
"dynamicsax-appfoundationtestcommon-develop",
"dynamicsax-appfoundationtestcommon-formadaptor",
"dynamicsax-application-applicationruntime",
"dynamicsax-applicationfoundation-compile",
"dynamicsax-applicationfoundation-develop",
"dynamicsax-applicationfoundation-formadaptor",
"dynamicsax-applicationfoundationformadaptor-compile",
"dynamicsax-applicationfoundationformadaptor-develop",
"dynamicsax-applicationfoundationformadaptor-formadaptor",
"dynamicsax-applicationfoundationunittests",
"dynamicsax-applicationfoundationunittests-compile",
"dynamicsax-applicationfoundationunittests-develop",
"dynamicsax-applicationfoundationunittests-formadaptor",
"dynamicsax-applicationplatform-compile",
"dynamicsax-applicationplatform-develop",
"dynamicsax-applicationplatform-formadaptor",
"dynamicsax-applicationplatformformadaptor-compile",
"dynamicsax-applicationplatformformadaptor-develop",
"dynamicsax-applicationplatformformadaptor-formadaptor",
"dynamicsax-applicationstaging",
"dynamicsax-applicationstaging-compile",
"dynamicsax-applicationstaging-develop",
"dynamicsax-applicationstagingformadaptor",
"dynamicsax-applicationstaging-formadaptor",
"dynamicsax-applicationstagingformadaptor-compile",
"dynamicsax-applicationstagingformadaptor-develop",
"dynamicsax-applicationstagingformadaptor-formadaptor",
"dynamicsax-applicationstagingtests",
"dynamicsax-applicationstagingtests-compile",
"dynamicsax-applicationstagingtests-develop",
"dynamicsax-applicationstagingtests-formadaptor",
"dynamicsax-applicationsuite-compile",
"dynamicsax-applicationsuite-develop",
"dynamicsax-applicationsuite-formadaptor",
"dynamicsax-applicationsuiteformadaptor-compile",
"dynamicsax-applicationsuiteformadaptor-develop",
"dynamicsax-applicationsuiteformadaptor-formadaptor",
"dynamicsax-applicationworkspaces-compile",
"dynamicsax-applicationworkspaces-develop",
"dynamicsax-applicationworkspacesformadaptor",
"dynamicsax-applicationworkspaces-formadaptor",
"dynamicsax-applicationworkspacesformadaptor-compile",
"dynamicsax-applicationworkspacesformadaptor-develop",
"dynamicsax-applicationworkspacesformadaptor-formadaptor",
"dynamicsax-applicationworkspacestests",
"dynamicsax-applicationworkspacestests-compile",
"dynamicsax-applicationworkspacestests-develop",
"dynamicsax-applicationworkspacestests-formadaptor",
"dynamicsax-appplatformtestcommon",
"dynamicsax-appplatformtestcommon-compile",
"dynamicsax-appplatformtestcommon-develop",
"dynamicsax-appplatformtestcommon-formadaptor",
"dynamicsax-appsuitetestcommon",
"dynamicsax-appsuitetestcommon-compile",
"dynamicsax-appsuitetestcommon-develop",
"dynamicsax-appsuitetestcommon-formadaptor",
"dynamicsax-budgetstaging",
"dynamicsax-budgetstaging-compile",
"dynamicsax-budgetstaging-develop",
"dynamicsax-budgetstagingformadaptor",
"dynamicsax-budgetstaging-formadaptor",
"dynamicsax-budgetstagingformadaptor-compile",
"dynamicsax-budgetstagingformadaptor-develop",
"dynamicsax-budgetstagingformadaptor-formadaptor",
"dynamicsax-budgetstagingtests",
"dynamicsax-budgetstagingtests-compile",
"dynamicsax-budgetstagingtests-develop",
"dynamicsax-budgetstagingtests-formadaptor",
"dynamicsax-calendar-compile",
"dynamicsax-calendar-develop",
"dynamicsax-calendarformadaptor",
"dynamicsax-calendar-formadaptor",
"dynamicsax-calendarformadaptor-compile",
"dynamicsax-calendarformadaptor-develop",
"dynamicsax-calendarformadaptor-formadaptor",
"dynamicsax-calendartests",
"dynamicsax-calendartests-compile",
"dynamicsax-calendartests-develop",
"dynamicsax-calendartests-formadaptor",
"dynamicsax-cirfoundationtests",
"dynamicsax-cirfoundationtests-compile",
"dynamicsax-cirfoundationtests-develop",
"dynamicsax-cirfoundationtests-formadaptor",
"dynamicsax-costaccounting",
"dynamicsax-costaccounting-compile",
"dynamicsax-costaccounting-develop",
"dynamicsax-costaccounting-formadaptor",
"dynamicsax-costaccountingformadaptor",
"dynamicsax-costaccountingformadaptor-compile",
"dynamicsax-costaccountingformadaptor-develop",
"dynamicsax-costaccountingformadaptor-formadaptor",
"dynamicsax-costaccountingtests",
"dynamicsax-costaccountingtests-compile",
"dynamicsax-costaccountingtests-develop",
"dynamicsax-costaccountingtests-formadaptor",
"dynamicsax-costaccountingax",
"dynamicsax-costaccountingax-compile",
"dynamicsax-costaccountingax-develop",
"dynamicsax-costaccountingax-formadaptor",
"dynamicsax-costaccountingaxformadaptor",
"dynamicsax-costaccountingaxformadaptor-compile",
"dynamicsax-costaccountingaxformadaptor-develop",
"dynamicsax-costaccountingaxformadaptor-formadaptor",
"dynamicsax-costaccountingaxtests",
"dynamicsax-costaccountingaxtests-compile",
"dynamicsax-costaccountingaxtests-develop",
"dynamicsax-costaccountingaxtests-formadaptor",
"dynamicsax-currency-compile",
"dynamicsax-currency-develop",
"dynamicsax-currencyformadaptor",
"dynamicsax-currency-formadaptor",
"dynamicsax-currencyformadaptor-compile",
"dynamicsax-currencyformadaptor-develop",
"dynamicsax-currencyformadaptor-formadaptor",
"dynamicsax-customeracceptancetests-compile",
"dynamicsax-customeracceptancetests-develop",
"dynamicsax-customeracceptancetests-formadaptor",
"dynamicsax-data-contoso",
"dynamicsax-data-demodata",
"dynamicsax-data-demovolumedata",
"dynamicsax-data-empty",
"dynamicsax-data-empty-platform",
"dynamicsax-dataimpexpapplication-compile",
"dynamicsax-dataimpexpapplication-develop",
"dynamicsax-dataimpexpapplication-formadaptor",
"dynamicsax-demodatasuite",
"dynamicsax-demodatasuite-compile",
"dynamicsax-demodatasuite-develop",
"dynamicsax-demodatasuite-formadaptor",
"dynamicsax-devtoolscustomizations",
"dynamicsax-devtoolscustomizations2",
"dynamicsax-devtoolscustomizations2-compile",
"dynamicsax-devtoolscustomizations2-develop",
"dynamicsax-devtoolscustomizations2-formadaptor",
"dynamicsax-devtoolscustomizations-compile",
"dynamicsax-devtoolscustomizations-develop",
"dynamicsax-devtoolscustomizations-formadaptor",
"dynamicsax-devtoolstestmodel",
"dynamicsax-devtoolstestmodel2",
"dynamicsax-devtoolstestmodel2-compile",
"dynamicsax-devtoolstestmodel2-develop",
"dynamicsax-devtoolstestmodel2-formadaptor",
"dynamicsax-devtoolstestmodel-compile",
"dynamicsax-devtoolstestmodel-develop",
"dynamicsax-devtoolstestmodel-formadaptor",
"dynamicsax-dimensions-compile",
"dynamicsax-dimensions-develop",
"dynamicsax-dimensionsformadaptor",
"dynamicsax-dimensions-formadaptor",
"dynamicsax-dimensionsformadaptor-compile",
"dynamicsax-dimensionsformadaptor-develop",
"dynamicsax-dimensionsformadaptor-formadaptor",
"dynamicsax-dimensionstestcommon",
"dynamicsax-dimensionstestcommon-compile",
"dynamicsax-dimensionstestcommon-develop",
"dynamicsax-dimensionstestcommon-formadaptor",
"dynamicsax-dimensionstests",
"dynamicsax-dimensionstests-compile",
"dynamicsax-dimensionstests-develop",
"dynamicsax-dimensionstests-formadaptor",
"dynamicsax-directory-compile",
"dynamicsax-directory-develop",
"dynamicsax-directory-formadaptor",
"dynamicsax-directoryformadaptor-compile",
"dynamicsax-directoryformadaptor-develop",
"dynamicsax-directoryformadaptor-formadaptor",
"dynamicsax-directorytests",
"dynamicsax-directorytests-compile",
"dynamicsax-directorytests-develop",
"dynamicsax-directorytests-formadaptor",
"dynamicsax-dispatchservice",
"dynamicsax-electronicreporting-compile",
"dynamicsax-electronicreporting-develop",
"dynamicsax-electronicreporting-formadaptor",
"dynamicsax-electronicreportingtestcommon",
"dynamicsax-electronicreportingtestcommon-compile",
"dynamicsax-electronicreportingtestcommon-develop",
"dynamicsax-electronicreportingtestcommon-formadaptor",
"dynamicsax-electronicreportingtests",
"dynamicsax-electronicreportingtests-compile",
"dynamicsax-electronicreportingtests-develop",
"dynamicsax-electronicreportingtests-formadaptor",
"dynamicsax-financialaccountingworkload",
"dynamicsax-financialaccountingworkload-compile",
"dynamicsax-financialaccountingworkload-develop",
"dynamicsax-financialaccountingworkload-formadaptor",
"dynamicsax-financialaccounting",
"dynamicsax-financialaccounting-compile",
"dynamicsax-financialaccounting-develop",
"dynamicsax-financialaccounting-formadaptor",
"dynamicsax-financialreportingadaptors",
"dynamicsax-financialreportingadaptors-compile",
"dynamicsax-financialreportingadaptors-develop",
"dynamicsax-financialreportingadaptors-formadaptor",
"dynamicsax-financialreporting-compile",
"dynamicsax-financialreporting-develop",
"dynamicsax-financialreporting-formadaptor",
"dynamicsax-financialreportingtestcommon",
"dynamicsax-financialreportingtestcommon-compile",
"dynamicsax-financialreportingtestcommon-develop",
"dynamicsax-financialreportingtestcommon-formadaptor",
"dynamicsax-financialreportingtests",
"dynamicsax-financialreportingtests-compile",
"dynamicsax-financialreportingtests-develop",
"dynamicsax-financialreportingtests-formadaptor",
"dynamicsax-fiscalbooks-compile",
"dynamicsax-fiscalbooks-develop",
"dynamicsax-fiscalbooksformadaptor",
"dynamicsax-fiscalbooks-formadaptor",
"dynamicsax-fiscalbooksformadaptor-compile",
"dynamicsax-fiscalbooksformadaptor-develop",
"dynamicsax-fiscalbooksformadaptor-formadaptor",
"dynamicsax-fiscalbookstests",
"dynamicsax-fiscalbookstests-compile",
"dynamicsax-fiscalbookstests-develop",
"dynamicsax-fiscalbookstests-formadaptor",
"dynamicsax-fleetmanagement-compile",
"dynamicsax-fleetmanagement-develop",
"dynamicsax-fleetmanagementextension-compile",
"dynamicsax-fleetmanagementextension-develop",
"dynamicsax-fleetmanagementextension-formadaptor",
"dynamicsax-fleetmanagement-formadaptor",
"dynamicsax-fleetmanagementunittests-compile",
"dynamicsax-fleetmanagementunittests-develop",
"dynamicsax-fleetmanagementunittests-formadaptor",
"dynamicsax-foundationtest",
"dynamicsax-foundationtestcommon",
"dynamicsax-foundationtestcommon-compile",
"dynamicsax-foundationtestcommon-develop",
"dynamicsax-foundationtestcommon-formadaptor",
"dynamicsax-foundationtest-compile",
"dynamicsax-foundationtest-develop",
"dynamicsax-foundationtest-formadaptor",
"dynamicsax-generalledger-compile",
"dynamicsax-generalledger-develop",
"dynamicsax-generalledgerformadaptor",
"dynamicsax-generalledger-formadaptor",
"dynamicsax-generalledgerformadaptor-compile",
"dynamicsax-generalledgerformadaptor-develop",
"dynamicsax-generalledgerformadaptor-formadaptor",
"dynamicsax-generalledgertests",
"dynamicsax-generalledgertests-compile",
"dynamicsax-generalledgertests-develop",
"dynamicsax-generalledgertests-formadaptor",
"dynamicsax-gfmtests",
"dynamicsax-gfmtests-compile",
"dynamicsax-gfmtests-develop",
"dynamicsax-gfmtests-formadaptor",
"dynamicsax-hcmtests",
"dynamicsax-hcmtests-compile",
"dynamicsax-hcmtests-develop",
"dynamicsax-hcmtests-formadaptor",
"dynamicsax-ledger-compile",
"dynamicsax-ledger-develop",
"dynamicsax-ledger-formadaptor",
"dynamicsax-ledgerformadaptor-compile",
"dynamicsax-ledgerformadaptor-develop",
"dynamicsax-ledgerformadaptor-formadaptor",
"dynamicsax-ledgertests",
"dynamicsax-ledgertests-compile",
"dynamicsax-ledgertests-develop",
"dynamicsax-ledgertests-formadaptor",
"dynamicsax-measurement-compile",
"dynamicsax-measurement-develop",
"dynamicsax-measurementformadaptor",
"dynamicsax-measurement-formadaptor",
"dynamicsax-measurementformadaptor-compile",
"dynamicsax-measurementformadaptor-develop",
"dynamicsax-measurementformadaptor-formadaptor",
"dynamicsax-measurementtests",
"dynamicsax-measurementtests-compile",
"dynamicsax-measurementtests-develop",
"dynamicsax-measurementtests-formadaptor",
"dynamicsax-meta-application-development",
"dynamicsax-meta-application-runtime",
"dynamicsax-meta-businessappplatform-development",
"dynamicsax-meta-businessappplatform-runtime",
"dynamicsax-meta-financialaccounting-development",
"dynamicsax-meta-financialaccounting-runtime",
"dynamicsax-meta-onebox-app-development",
"dynamicsax-meta-onebox-app-runtime",
"dynamicsax-meta-onebox-financialaccounting-development",
"dynamicsax-meta-onebox-financialaccounting-runtime",
"dynamicsax-meta-onebox-platform-development",
"dynamicsax-meta-onebox-platform-runtime",
"dynamicsax-meta-platform-development",
"dynamicsax-meta-platform-runtime",
"dynamicsax-OrchestrationPlugins",
"dynamicsax-organization-compile",
"dynamicsax-organization-develop",
"dynamicsax-organizationformadaptor",
"dynamicsax-organization-formadaptor",
"dynamicsax-organizationformadaptor-compile",
"dynamicsax-organizationformadaptor-develop",
"dynamicsax-organizationformadaptor-formadaptor",
"dynamicsax-organizationtests",
"dynamicsax-organizationtests-compile",
"dynamicsax-organizationtests-develop",
"dynamicsax-organizationtests-formadaptor",
"dynamicsax-payroll-compile",
"dynamicsax-payroll-develop",
"dynamicsax-payrollformadaptor",
"dynamicsax-payroll-formadaptor",
"dynamicsax-payrollformadaptor-compile",
"dynamicsax-payrollformadaptor-develop",
"dynamicsax-payrollformadaptor-formadaptor",
"dynamicsax-payrolltests",
"dynamicsax-payrolltests-compile",
"dynamicsax-payrolltests-develop",
"dynamicsax-payrolltests-formadaptor",
"dynamicsax-performancetest",
"dynamicsax-performancetest-compile",
"dynamicsax-performancetest-develop",
"dynamicsax-performancetest-formadaptor",
"dynamicsax-performancetool",
"dynamicsax-performancetool-compile",
"dynamicsax-performancetool-develop",
"dynamicsax-performancetool-formadaptor",
"dynamicsax-performancetoolunittests",
"dynamicsax-performancetoolunittests-compile",
"dynamicsax-performancetoolunittests-develop",
"dynamicsax-performancetoolunittests-formadaptor",
"dynamicsax-policy-compile",
"dynamicsax-policy-develop",
"dynamicsax-policyformadaptor",
"dynamicsax-policy-formadaptor",
"dynamicsax-policyformadaptor-compile",
"dynamicsax-policyformadaptor-develop",
"dynamicsax-policyformadaptor-formadaptor",
"dynamicsax-policytests",
"dynamicsax-policytests-compile",
"dynamicsax-policytests-develop",
"dynamicsax-policytests-formadaptor",
"dynamicsax-primitivetest",
"dynamicsax-primitivetest-compile",
"dynamicsax-primitivetest-develop",
"dynamicsax-primitivetest-formadaptor",
"dynamicsax-productconfiguration",
"dynamicsax-publicsector-compile",
"dynamicsax-publicsector-develop",
"dynamicsax-publicsectorformadaptor",
"dynamicsax-publicsector-formadaptor",
"dynamicsax-publicsectorformadaptor-compile",
"dynamicsax-publicsectorformadaptor-develop",
"dynamicsax-publicsectorformadaptor-formadaptor",
"dynamicsax-publicsectortests",
"dynamicsax-publicsectortests-compile",
"dynamicsax-publicsectortests-develop",
"dynamicsax-publicsectortests-formadaptor",
"dynamicsax-retailtests",
"dynamicsax-retailtests-compile",
"dynamicsax-retailtests-develop",
"dynamicsax-retailtests-formadaptor",
"dynamicsax-scmtests",
"dynamicsax-scmtests-compile",
"dynamicsax-scmtests-develop",
"dynamicsax-scmtests-formadaptor",
"dynamicsax-scmteststaging",
"dynamicsax-scmteststaging-compile",
"dynamicsax-scmteststaging-develop",
"dynamicsax-scmteststaging-formadaptor",
"dynamicsax-servertests",
"dynamicsax-servertests-compile",
"dynamicsax-servertests-develop",
"dynamicsax-servertests-formadaptor",
"dynamicsax-sitests",
"dynamicsax-sitests-compile",
"dynamicsax-sitests-develop",
"dynamicsax-sitests-formadaptor",
"dynamicsax-sourcedocumentation-compile",
"dynamicsax-sourcedocumentation-develop",
"dynamicsax-sourcedocumentationformadaptor",
"dynamicsax-sourcedocumentation-formadaptor",
"dynamicsax-sourcedocumentationformadaptor-compile",
"dynamicsax-sourcedocumentationformadaptor-develop",
"dynamicsax-sourcedocumentationformadaptor-formadaptor",
"dynamicsax-sourcedocumentationtypes-compile",
"dynamicsax-sourcedocumentationtypes-develop",
"dynamicsax-sourcedocumentationtypes-formadaptor",
"dynamicsax-sourcedocumentationtests",
"dynamicsax-sourcedocumentationtests-compile",
"dynamicsax-sourcedocumentationtests-develop",
"dynamicsax-sourcedocumentationtests-formadaptor",
"dynamicsax-subledger-compile",
"dynamicsax-subledger-develop",
"dynamicsax-subledgerformadaptor",
"dynamicsax-subledger-formadaptor",
"dynamicsax-subledgerformadaptor-compile",
"dynamicsax-subledgerformadaptor-develop",
"dynamicsax-subledgerformadaptor-formadaptor",
"dynamicsax-sysfake",
"dynamicsax-sysfake-compile",
"dynamicsax-sysfake-develop",
"dynamicsax-sysfake-formadaptor",
"dynamicsax-tax-compile",
"dynamicsax-tax-develop",
"dynamicsax-taxformadaptor",
"dynamicsax-tax-formadaptor",
"dynamicsax-taxformadaptor-compile",
"dynamicsax-taxformadaptor-develop",
"dynamicsax-taxformadaptor-formadaptor",
"dynamicsax-test",
"dynamicsax-test-compile",
"dynamicsax-test-develop",
"dynamicsax-testessentials-compile",
"dynamicsax-testessentials-develop",
"dynamicsax-testessentials-formadaptor",
"dynamicsax-test-formadaptor",
"dynamicsax-tutorial-compile",
"dynamicsax-tutorial-develop",
"dynamicsax-tutorial-formadaptor",
"dynamicsax-unitofmeasure-compile",
"dynamicsax-unitofmeasure-develop",
"dynamicsax-unitofmeasure-formadaptor",
"dynamicsax-unitofmeasureformadaptor-compile",
"dynamicsax-unitofmeasureformadaptor-develop",
"dynamicsax-unitofmeasureformadaptor-formadaptor",
"dynamicsax-unittests",
"dynamicsax-unittests-compile",
"dynamicsax-unittests-develop",
"dynamicsax-unittests-formadaptor",
"dynamicsax-upgrade",
"dynamicsax-upgrade-compile",
"dynamicsax-upgrade-develop",
"dynamicsax-upgrade-formadaptor")

$sourcePath = [IO.Path]::Combine($(split-Path -parent $PSScriptRoot), "Packages")
$files=get-childitem -Path:$sourcePath *.nupkg
foreach ($file in $files) 
{
    $fileName =  ($file.BaseName).Split(".")[0]
    if ($blockListedPackage -contains "$fileName")
    {
        write-output "Removing $file from packaging folder"
        remove-item $file.FullName
    }
}

# SIG # Begin signature block
# MIIr9gYJKoZIhvcNAQcCoIIr5zCCK+MCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC8u6LYZSpJHT4/
# ga/LfkGNrpLG3Gc5/F+u7/pnwhnT3KCCEX0wggiNMIIHdaADAgECAhM2AAAByXAh
# sYa3QLIdAAIAAAHJMA0GCSqGSIb3DQEBCwUAMEExEzARBgoJkiaJk/IsZAEZFgNH
# QkwxEzARBgoJkiaJk/IsZAEZFgNBTUUxFTATBgNVBAMTDEFNRSBDUyBDQSAwMTAe
# Fw0yMzAzMjAyMDAwMzFaFw0yNDAzMTkyMDAwMzFaMCQxIjAgBgNVBAMTGU1pY3Jv
# c29mdCBBenVyZSBDb2RlIFNpZ24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQDFr1S7Edy7g+IOTvkgvCnHZ8IFO9YYz7Qj3VmU4sReYnyWfJGG3gDy3915
# A1RRYC8XGg4tcRb4Q4G81hRjwRHBn5BGGyn12aiQe8Rc+pQDUWf5AGagU24fTGaa
# oMvPRMpDf2aEBzSOfYFFnZxR4LALimoIds1aBgtrOfgAMRP4AYYp+uocACiHGvXj
# zuwT6Rt6v9utDlvmvrVKWnP/iZwGNcNELPtJD0EuTUZukwv4ctDabrJQT63xXnvL
# VbHuFDzpZkRopK1bgkjVwshk9ocnU1Hn26iXNdSu+6CVjKu5zAnbj0mENioEQYPG
# 5sYOs1Bdig46d9B9vLTeyuPniP9nAgMBAAGjggWZMIIFlTApBgkrBgEEAYI3FQoE
# HDAaMAwGCisGAQQBgjdbAQEwCgYIKwYBBQUHAwMwPQYJKwYBBAGCNxUHBDAwLgYm
# KwYBBAGCNxUIhpDjDYTVtHiE8Ys+hZvdFs6dEoFgg93NZoaUjDICAWQCAQwwggJ2
# BggrBgEFBQcBAQSCAmgwggJkMGIGCCsGAQUFBzAChlZodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpaW5mcmEvQ2VydHMvQlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1F
# JTIwQ1MlMjBDQSUyMDAxKDIpLmNydDBSBggrBgEFBQcwAoZGaHR0cDovL2NybDEu
# YW1lLmdibC9haWEvQlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1FJTIwQ1MlMjBDQSUy
# MDAxKDIpLmNydDBSBggrBgEFBQcwAoZGaHR0cDovL2NybDIuYW1lLmdibC9haWEv
# QlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1FJTIwQ1MlMjBDQSUyMDAxKDIpLmNydDBS
# BggrBgEFBQcwAoZGaHR0cDovL2NybDMuYW1lLmdibC9haWEvQlkyUEtJQ1NDQTAx
# LkFNRS5HQkxfQU1FJTIwQ1MlMjBDQSUyMDAxKDIpLmNydDBSBggrBgEFBQcwAoZG
# aHR0cDovL2NybDQuYW1lLmdibC9haWEvQlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1F
# JTIwQ1MlMjBDQSUyMDAxKDIpLmNydDCBrQYIKwYBBQUHMAKGgaBsZGFwOi8vL0NO
# PUFNRSUyMENTJTIwQ0ElMjAwMSxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIwU2Vy
# dmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1BTUUsREM9R0JM
# P2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RDbGFzcz1jZXJ0aWZpY2F0aW9uQXV0
# aG9yaXR5MB0GA1UdDgQWBBSdVHKBvte+PBNbYdCE96iKceXbHDAOBgNVHQ8BAf8E
# BAMCB4AwVAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5k
# IE9wZXJhdGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjM2MTY3KzUwMDM2MTCCAeYG
# A1UdHwSCAd0wggHZMIIB1aCCAdGgggHNhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5j
# b20vcGtpaW5mcmEvQ1JML0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcmyGMWh0dHA6
# Ly9jcmwxLmFtZS5nYmwvY3JsL0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcmyGMWh0
# dHA6Ly9jcmwyLmFtZS5nYmwvY3JsL0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcmyG
# MWh0dHA6Ly9jcmwzLmFtZS5nYmwvY3JsL0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5j
# cmyGMWh0dHA6Ly9jcmw0LmFtZS5nYmwvY3JsL0FNRSUyMENTJTIwQ0ElMjAwMSgy
# KS5jcmyGgb1sZGFwOi8vL0NOPUFNRSUyMENTJTIwQ0ElMjAwMSgyKSxDTj1CWTJQ
# S0lDU0NBMDEsQ049Q0RQLENOPVB1YmxpYyUyMEtleSUyMFNlcnZpY2VzLENOPVNl
# cnZpY2VzLENOPUNvbmZpZ3VyYXRpb24sREM9QU1FLERDPUdCTD9jZXJ0aWZpY2F0
# ZVJldm9jYXRpb25MaXN0P2Jhc2U/b2JqZWN0Q2xhc3M9Y1JMRGlzdHJpYnV0aW9u
# UG9pbnQwHwYDVR0jBBgwFoAUllGE4Gtve/7YBqvD8oXmKa5q+dQwHwYDVR0lBBgw
# FgYKKwYBBAGCN1sBAQYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggEBAEGngK3p
# DE2ArGuR5Yg12mZXM7Af4BPktIJ96ppBeUa1Fjz84dAQkqS1y7srk6cCPMfaZjJa
# LnsQlBvrKCkYpLP6qiDq3+Pyd6WyQOvwiGFmH/VY4465zNZNqsE7CW4+nEMmJtMf
# dz+gUOizkWdNPQzKOBwmvPft+9Y8CgLwm8IBa7ZLH3I7cGix1gI8xxzz0w8JUnK+
# vjZk2B4krx+kSEk/9y1HaDBC16GcEb4HsJbI1vkYD1f4CBc9CgMzdc8NDB55f81G
# MdT9wTELePxZbXZva2c6Z3a75Wso7xlrT0U3WW9oX5VR0+8Qqbw6+16/bKRVGrrA
# SIT4h2lfE8RIMf8wggjoMIIG0KADAgECAhMfAAAAUeqP9pxzDKg7AAAAAABRMA0G
# CSqGSIb3DQEBCwUAMDwxEzARBgoJkiaJk/IsZAEZFgNHQkwxEzARBgoJkiaJk/Is
# ZAEZFgNBTUUxEDAOBgNVBAMTB2FtZXJvb3QwHhcNMjEwNTIxMTg0NDE0WhcNMjYw
# NTIxMTg1NDE0WjBBMRMwEQYKCZImiZPyLGQBGRYDR0JMMRMwEQYKCZImiZPyLGQB
# GRYDQU1FMRUwEwYDVQQDEwxBTUUgQ1MgQ0EgMDEwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQDJmlIJfQGejVbXKpcyFPoFSUllalrinfEV6JMc7i+bZDoL
# 9rNHnHDGfJgeuRIYO1LY/1f4oMTrhXbSaYRCS5vGc8145WcTZG908bGDCWr4GFLc
# 411WxA+Pv2rteAcz0eHMH36qTQ8L0o3XOb2n+x7KJFLokXV1s6pF/WlSXsUBXGaC
# IIWBXyEchv+sM9eKDsUOLdLTITHYJQNWkiryMSEbxqdQUTVZjEz6eLRLkofDAo8p
# XirIYOgM770CYOiZrcKHK7lYOVblx22pdNawY8Te6a2dfoCaWV1QUuazg5VHiC4p
# /6fksgEILptOKhx9c+iapiNhMrHsAYx9pUtppeaFAgMBAAGjggTcMIIE2DASBgkr
# BgEEAYI3FQEEBQIDAgACMCMGCSsGAQQBgjcVAgQWBBQSaCRCIUfL1Gu+Mc8gpMAL
# I38/RzAdBgNVHQ4EFgQUllGE4Gtve/7YBqvD8oXmKa5q+dQwggEEBgNVHSUEgfww
# gfkGBysGAQUCAwUGCCsGAQUFBwMBBggrBgEFBQcDAgYKKwYBBAGCNxQCAQYJKwYB
# BAGCNxUGBgorBgEEAYI3CgMMBgkrBgEEAYI3FQYGCCsGAQUFBwMJBggrBgEFBQgC
# AgYKKwYBBAGCN0ABAQYLKwYBBAGCNwoDBAEGCisGAQQBgjcKAwQGCSsGAQQBgjcV
# BQYKKwYBBAGCNxQCAgYKKwYBBAGCNxQCAwYIKwYBBQUHAwMGCisGAQQBgjdbAQEG
# CisGAQQBgjdbAgEGCisGAQQBgjdbAwEGCisGAQQBgjdbBQEGCisGAQQBgjdbBAEG
# CisGAQQBgjdbBAIwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQD
# AgGGMBIGA1UdEwEB/wQIMAYBAf8CAQAwHwYDVR0jBBgwFoAUKV5RXmSuNLnrrJwN
# p4x1AdEJCygwggFoBgNVHR8EggFfMIIBWzCCAVegggFToIIBT4YxaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraWluZnJhL2NybC9hbWVyb290LmNybIYjaHR0cDov
# L2NybDIuYW1lLmdibC9jcmwvYW1lcm9vdC5jcmyGI2h0dHA6Ly9jcmwzLmFtZS5n
# YmwvY3JsL2FtZXJvb3QuY3JshiNodHRwOi8vY3JsMS5hbWUuZ2JsL2NybC9hbWVy
# b290LmNybIaBqmxkYXA6Ly8vQ049YW1lcm9vdCxDTj1BTUVSb290LENOPUNEUCxD
# Tj1QdWJsaWMlMjBLZXklMjBTZXJ2aWNlcyxDTj1TZXJ2aWNlcyxDTj1Db25maWd1
# cmF0aW9uLERDPUFNRSxEQz1HQkw/Y2VydGlmaWNhdGVSZXZvY2F0aW9uTGlzdD9i
# YXNlP29iamVjdENsYXNzPWNSTERpc3RyaWJ1dGlvblBvaW50MIIBqwYIKwYBBQUH
# AQEEggGdMIIBmTBHBggrBgEFBQcwAoY7aHR0cDovL2NybC5taWNyb3NvZnQuY29t
# L3BraWluZnJhL2NlcnRzL0FNRVJvb3RfYW1lcm9vdC5jcnQwNwYIKwYBBQUHMAKG
# K2h0dHA6Ly9jcmwyLmFtZS5nYmwvYWlhL0FNRVJvb3RfYW1lcm9vdC5jcnQwNwYI
# KwYBBQUHMAKGK2h0dHA6Ly9jcmwzLmFtZS5nYmwvYWlhL0FNRVJvb3RfYW1lcm9v
# dC5jcnQwNwYIKwYBBQUHMAKGK2h0dHA6Ly9jcmwxLmFtZS5nYmwvYWlhL0FNRVJv
# b3RfYW1lcm9vdC5jcnQwgaIGCCsGAQUFBzAChoGVbGRhcDovLy9DTj1hbWVyb290
# LENOPUFJQSxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2aWNlcyxDTj1TZXJ2aWNlcyxD
# Tj1Db25maWd1cmF0aW9uLERDPUFNRSxEQz1HQkw/Y0FDZXJ0aWZpY2F0ZT9iYXNl
# P29iamVjdENsYXNzPWNlcnRpZmljYXRpb25BdXRob3JpdHkwDQYJKoZIhvcNAQEL
# BQADggIBAFAQI7dPD+jfXtGt3vJp2pyzA/HUu8hjKaRpM3opya5G3ocprRd7vdTH
# b8BDfRN+AD0YEmeDB5HKQoG6xHPI5TXuIi5sm/LeADbV3C2q0HQOygS/VT+m1W7a
# /752hMIn+L4ZuyxVeSBpfwf7oQ4YSZPh6+ngZvBHgfBaVz4O9/wcfw91QDZnTgK9
# zAh9yRKKls2bziPEnxeOZMVNaxyV0v152PY2xjqIafIkUjK6vY9LtVFjJXenVUAm
# n3WCPWNFC1YTIIHw/mD2cTfPy7QA1pT+GPARAKt0bKtq9aCd/Ym0b5tPbpgCiRtz
# yb7fbNS1dE740re0COE67YV2wbeo2sXixzvLftH8L7s9xv9wV+G22qyKt6lmKLjF
# K1yMw4Ni5fMabcgmzRvSjAcbqgp3tk4a8emaaH0rz8MuuIP+yrxtREPXSqL/C5bz
# MzsikuDW9xH10graZzSmPjilzpRfRdu20/9UQmC7eVPZ4j1WNa1oqPHfzET3ChIz
# J6Q9G3NPCB+7KwX0OQmKyv7IDimj8U/GlsHD1z+EF/fYMf8YXG15LamaOAohsw/y
# wO6SYSreVW+5Y0mzJutnBC9Cm9ozj1+/4kqksrlhZgR/CSxhFH3BTweH8gP2FEIS
# RtShDZbuYymynY1un+RyfiK9+iVTLdD1h/SxyxDpZMtimb4CgJQlMYIZzzCCGcsC
# AQEwWDBBMRMwEQYKCZImiZPyLGQBGRYDR0JMMRMwEQYKCZImiZPyLGQBGRYDQU1F
# MRUwEwYDVQQDEwxBTUUgQ1MgQ0EgMDECEzYAAAHJcCGxhrdAsh0AAgAAAckwDQYJ
# YIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPcTRSXWxELw
# HSROfVGlyFii8+X1xMgxaUgMAl9E/lH+MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBN
# AGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJ
# KoZIhvcNAQEBBQAEggEAjsiC5YVxd1nP65y7351Jf4XCO737YCxOLBvHo0WvQb33
# CTJwRKilpJvvMs9+TjJLT5iFLZhA2l2yrtOn1GKaCpX4PjatjCEGjXVALGJXzvcB
# Or+1LFNI18hlalZX7CaLLRqC9RFU3d7iZq7YItrAV35Ay1VzVqtaRRwq+5yAa68R
# gn+IuFe0wqvBypZSsr0vq3ewiBbUf92PAWgGXd/ckgbA60Z8dUZzlbTQhX7+C+Fq
# j0jyzxhgPAB7dPuMpJPgBhVXRfusiJcYk1WWzPL/rUjWNi8eQ4tWe6SNCtAv/JX0
# Rl9x/ddwKGUxKDxV9Ab1jvzNGpNLtMKf16ELQXJ5b6GCF5cwgheTBgorBgEEAYI3
# AwMBMYIXgzCCF38GCSqGSIb3DQEHAqCCF3AwghdsAgEDMQ8wDQYJYIZIAWUDBAIB
# BQAwggFSBgsqhkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAx
# MA0GCWCGSAFlAwQCAQUABCDSt2RSbOWD7mVO4Qy+IaDQWCoyZQwG3xvinJZWOPqK
# nwIGZQPVulTBGBMyMDIzMDkxODE3MDQxMy40MzdaMASAAgH0oIHRpIHOMIHLMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNy
# b3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBF
# U046QTQwMC0wNUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFNlcnZpY2WgghHtMIIHIDCCBQigAwIBAgITMwAAAdYnaf9yLVbIrgABAAAB1jAN
# BgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0y
# MzA1MjUxOTEyMzRaFw0yNDAyMDExOTEyMzRaMIHLMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBP
# cGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046QTQwMC0wNUUwLUQ5
# NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0G
# CSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDPLM2Om8r5u3fcbDEOXydJtbkW5U34
# KFaftC+8QyNqplMIzSTC1ToE0zcweQCvPIfpYtyPB3jt6fPRprvhwCksUw9p0Ofm
# ZzWPDvkt40BUStu813QlrloRdplLz2xpk29jIOZ4+rBbKaZkBPZ4R4LXQhkkHne0
# Y/Yh85ZqMMRaMWkBM6nUwV5aDiwXqdE9Jyl0i1aWYbCqzwBRdN7CTlAJxrJ47ov3
# uf/lFg9hnVQcqQYgRrRFpDNFMOP0gwz5Nj6a24GZncFEGRmKwImL+5KWPnVgvadJ
# SRp6ZqrYV3FmbBmZtsF0hSlVjLQO8nxelGV7TvqIISIsv2bQMgUBVEz8wHFyU386
# 3gHj8BCbEpJzm75fLJsL3P66lJUNRN7CRsfNEbHdX/d6jopVOFwF7ommTQjpU37A
# /7YR0wJDTt6ZsXU+j/wYlo9b22t1qUthqjRs32oGf2TRTCoQWLhJe3cAIYRlla/g
# EKlbuDDsG3926y4EMHFxTjsjrcZEbDWwjB3wrp11Dyg1QKcDyLUs2anBolvQwJTN
# 0mMOuXO8tBz20ng/+Xw+4w+W9PMkvW1faYi435VjKRZsHfxIPjIzZ0wf4FibmVPJ
# HZ+aTxGsVJPxydChvvGCf4fe8XfYY9P5lbn9ScKc4adTd44GCrBlJ/JOsoA4OvNH
# Y6W+XcKVcIIGWwIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFGGaVDY7TQBiMCKg2+j/
# zRTcYsZOMB8GA1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRY
# MFYwVKBSoFCGTmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01p
# Y3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEF
# BQcBAQRgMF4wXAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAo
# MSkuY3J0MAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYD
# VR0PAQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4ICAQDUv+RjNidwJxSbMk1IvS8L
# fxNM8VaVhpxR1SkW+FRY6AKkn2s3On29nGEVlatblIv1qVTKkrUxLYMZ0z+RA6mm
# fXue2Y7/YBbzM5kUeUgU2y1Mmbin6xadT9DzECeE7E4+3k2DmZxuV+GLFYQsqkDb
# e8oy7+3BSiU29qyZAYT9vRDALPUC5ZwyoPkNfKbqjl3VgFTqIubEQr56M0YdMWlq
# Cqq0yVln9mPbhHHzXHOjaQsurohHCf7VT8ct79po34Fd8XcsqmyhdKBy1jdyknri
# k+F3vEl/90qaon5N8KTZoGtOFlaJFPnZ2DqQtb2WWkfuAoGWrGSA43Myl7+PYbUs
# ri/NrMvAd9Z+J9FlqsMwXQFxAB7ujJi4hP8BH8j6qkmy4uulU5SSQa6XkElcaKQY
# SpJcSjkjyTDIOpf6LZBTaFx6eeoqDZ0lURhiRqO+1yo8uXO89e6kgBeC8t1WN5IT
# qXnjocYgDvyFpptsUDgnRUiI1M/Ql/O299VktMkIL72i6Qd4BBsrj3Z+iLEnKP9e
# pUwosP1m3N2v9yhXQ1HiusJl63IfXIyfBJaWvQDgU3Jk4eIZSr/2KIj4ptXt496C
# RiHTi011kcwDpdjQLAQiCvoj1puyhfwVf2G5ZwBptIXivNRba34KkD5oqmEoF1yR
# FQ84iDsf/giyn/XIT7YY/zCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAA
# ABUwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1
# dGhvcml0eSAyMDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWlj
# cm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/
# bErg4r25PhdgM/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNE
# t6aORmsHFPPFdvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2
# Nr41JmTamDu6GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOOR
# j7I5LFGc6XBpDco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnop
# N6zL64NF50ZuyjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0g
# z3N9QZpGdc3EXzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/
# BQOj0XOmTTd0lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8Qmgu
# EOqEUUbi0b1qGFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFd
# XzB0kZSU2LlQ+QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y
# 7435UsSFF5PAPBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQAB
# o4IB3TCCAdkwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS
# /mTEmr6CkTxGNSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1Gely
# MFwGA1UdIARVMFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTAT
# BgNVHSUEDDAKBggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+ii
# XGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0y
# My5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNy
# dDANBgkqhkiG9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5O
# R2R4sQaTlz0xM7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6
# th542DYunKmCVgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhT
# dSRXud2f8449xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnD
# vBewVIVCs/wMnosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvf
# SaN0DLzskYDSPeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+
# CljdQDzHVG2dY3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5a
# GZFrDZ+kKNxnGSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+
# fKFhbHP+CrvsQWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmN
# cP7ntdAoGokLjzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGe
# Pu1+oDEzfbzL6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNY
# s6FwZvKhggNQMIICOAIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3Bl
# cmF0aW9uczEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOkE0MDAtMDVFMC1EOTQ3
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYF
# Kw4DAhoDFQD5r3DVRpAGQo9sTLUHeBC87NpK+qCBgzCBgKR+MHwxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA6LLxKzAiGA8yMDIz
# MDkxODE1NTQxOVoYDzIwMjMwOTE5MTU1NDE5WjB3MD0GCisGAQQBhFkKBAExLzAt
# MAoCBQDosvErAgEAMAoCAQACAg7AAgH/MAcCAQACAhQKMAoCBQDotEKrAgEAMDYG
# CisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEA
# AgMBhqAwDQYJKoZIhvcNAQELBQADggEBAEf5dcpBfvEXsM174LeCx7qiRXud+dBM
# oxPApXJV8qkD4mLjQVzWNPd+8gejIwC6TUNRdWcyPMGqMx0NWbUeDC6P2zXUfCTY
# ZZaEzLVDA1FzqATifuNkgLK8yH23KzsDoFy2UcJzzXe5B0Sor5KukE2qJhTEVxDX
# +eT/xZEhBTaEABlt0YMuh03GIjqjouF/JsuBs45UFWkfmiGW4nkC3oSuRja6cwi7
# qEbReNAfb0+CKK8KRTgGFkrYAFLR/GSp/Lz00Kc4YcjkyRZv9q9M7FFBDBDynwvg
# vCwvHQGN1pdi2K1q0sjJa8PWAzV/PbbO6/qS3e+czgZdnGkSg/15wE4xggQNMIIE
# CQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAdYnaf9y
# LVbIrgABAAAB1jANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqG
# SIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCAAioA9+bTy+9N0tik/W07JTt2OeuOd
# PzPRxnF5pJSjZzCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EINbLTQ1XeNM+
# EBinOEJMjZd0jMNDur+AK+O8P12j5ST8MIGYMIGApH4wfDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBIDIwMTACEzMAAAHWJ2n/ci1WyK4AAQAAAdYwIgQgGUDFMorjPDQX
# Q/TG3M5WDF9OX77LAuDIGkdTdbyI3EcwDQYJKoZIhvcNAQELBQAEggIAvYH86iGk
# rmflhUsF9VJuNc6P/XfULy9reYtJkTSP+vebcSUqt/Lm8jPVcor7E2+ccF43RHln
# 8asH66nDXW4rr6ZqKrq6kD0S1fq/1dSQcxt5KaUQXC6J957QCFqRc4WIpK73jsze
# 27N8fmlV9jwoQ5MThXbvvnvejlfbyep++ujXvFx2AU4bMOgz6Tyz4PMmcSNWSRAK
# XztuxtyhSfNzXA6+tZOZImrwMvmQ+T2gFt2eICHp6xZYNLSQOf1WcP6ZLKLuwrVG
# kOwy0x3RF7R737L7x02l9TInB4+syUW1XcCz2lZFJSdCy7oNrVtOp3gwLXoucr91
# /+KY3hBg0uTJcPicE8aYLfno7cHz8APaFQsO9Aw0XC6oUheTwND7hRHNf+HX+qE1
# ruQsbkYq+5/n/dG6YxkO67pKgCmUgcZhAt6WW/iU5USAn3Hj41UFfZBIxzWv9CNE
# wTPN8n41YvRQUc+oik7Ivid51TekzUUq9CMQ5xlI6byM3BXSAfcz1jjpwCmpdgtk
# q5VrIQwIuOWQbYUV+w1nuhukmfam8K69lecpNEllPEXiUtvjOXQmGODiBI8D1Svg
# YRSR5G1UiHak6iQl6T9agH6k+iBei9fNuTlgEAHUGJ4kKBYDWRiB0i6P1ivJ7Ye+
# varx1zUEY6iQnGUCpaOhG5zZGDb7Q4OKZfY=
# SIG # End signature block
