﻿param
(
    [Parameter(Mandatory=$true)]
    $config,
    [Parameter(Mandatory=$true)]
    $log
)

Import-Module "$PSScriptRoot\AosCommon.psm1" -Force -DisableNameChecking

function RemoveHttpModule($webConfig, $location, $httpModuleName)
{
    Write-Log "Adding remove $httpModuleName HTTP module for $location location"
    $webHttpRemoveModules = $webConfig.SelectNodes("configuration/location[@path='$location']/system.webServer/modules")
    $httpRemoveModule = $webHttpRemoveModules.remove | where { $_.name -eq $httpModuleName }
    if ($httpRemoveModule -eq $null)
    {
        $newAdd = $webConfig.CreateElement("remove")
        $newAdd.SetAttribute("name", "$httpModuleName")
        $webHttpRemoveModules.AppendChild($newAdd) | Out-Null    
    }
}

function ConfigureHttp-WebConfig($settings)
{
    Write-Log "Configuring web.config for HTTP"
    $WebRootPath = $settings.'Infrastructure.WebRoot'

    Write-Log "Setting webHttpBinding security to None"
    [xml]$webConfig = Get-Content "$WebRootPath\web.config"
    $webBindingSecurity = $webConfig.SelectNodes("configuration/location/system.serviceModel/bindings/webHttpBinding/binding/security")

    foreach ($bindingSecurity in $webBindingSecurity)
    {
        $bindingSecurity.mode = "None"
    }

    Write-Log "Adding SecureCookieHttpModule HTTP module"
    $SecureCookieHttpModuleName = "SecureCookieHttpModule"
    $webHttpModules = $webConfig.SelectNodes("configuration/system.webServer/modules")
    $secureCookieModule = $webHttpModules.add | where { $_.name -eq $SecureCookieHttpModuleName }
    if ($secureCookieModule -eq $null)
    {
        $newAdd = $webConfig.CreateElement("add")
        $newAdd.SetAttribute("name", "$SecureCookieHttpModuleName")
        $newAdd.SetAttribute("type", "Microsoft.Dynamics.AX.HttpModule.SecureCookieHttpModule, AOSKernel, Version=7.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35")
        $newAdd.SetAttribute("preCondition", "managedHandler")
        $webHttpModules.AppendChild($newAdd) | Out-Null    
    }

    $webConfig.Save("$WebRootPath\web.config")  
}

function ConfigureHttp-WifServicesConfig($settings)
{
    Write-Log "Configuring wif.services.config for HTTP"
    $WebRootPath = $settings.'Infrastructure.WebRoot'

    Write-Log "Setting requireSsl = false in wif.services.config"
    [xml]$wifServices = Get-Content "$WebRootPath\wif.services.config"
    $cookieHandler = $wifServices.SelectSingleNode("system.identityModel.services/federationConfiguration/cookieHandler")

    $cookieHandler.requireSsl = "false"

    $wifServices.Save("$WebRootPath\wif.services.config")   
}

function ConfigureHttp-IIS($settings)
{
    Write-Log "Adding website HTTP binding" 

    Import-Module WebAdministration

    $AosWebSiteName = $settings.'Infrastructure.ApplicationName'
    $AosWebSite = Get-Website -Name "$AosWebSiteName"
    $existingBinding = Get-WebBinding -Name "$AosWebSiteName" -Protocol "https" -Port 443
    if($existingBinding -eq $null)
    {    
        Write-Log "Https binding is not configured, configure http binding from IIS management console."
    }
    
    $hostheader = $existingBinding.bindingInformation.Split(":") | select -Last 1

    New-WebBinding -Name "$AosWebSiteName" -Force -HostHeader "$hostheader" -IPAddress "*" -port 80 -Protocol "http"
}

Initialize-Log $log
Write-Log "Decoding settings"
$settings = Decode-Settings $config

# in powershell this is case-insensitive
if ($settings.'Infrastructure.HttpProtocol' -eq "Http")
{
    Write-Log "Updating AOS web.config for HTTP"
    ConfigureHttp-WebConfig $settings
    Write-Log "AOS web.config update complete"

    Write-Log "Updating AOS wif.services.config for HTTP"
    ConfigureHttp-WifServicesConfig $settings
    Write-Log "AOS wif.services.config update complete"

<#
    Write-Log "Updating AOS IIS website configuration"
    ConfigureHttp-IIS $settings
    Write-Log "AOS IIS website configuration update complete"
#>

    Restart-IIS

    Write-Log "AOS Http configuration complete, exiting"
}
else
{
    Restart-IIS
    Write-Log "Protocol is set to $($settings.'Infrastructure.HttpProtocol'), exiting."
}
# SIG # Begin signature block
# MIIoOwYJKoZIhvcNAQcCoIIoLDCCKCgCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDkrBAn07Liw+Gx
# RFpx9i7rBjEAfgxgMLg3xjuHqawOVKCCDYUwggYDMIID66ADAgECAhMzAAADri01
# UchTj1UdAAAAAAOuMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwODU5WhcNMjQxMTE0MTkwODU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQD0IPymNjfDEKg+YyE6SjDvJwKW1+pieqTjAY0CnOHZ1Nj5irGjNZPMlQ4HfxXG
# yAVCZcEWE4x2sZgam872R1s0+TAelOtbqFmoW4suJHAYoTHhkznNVKpscm5fZ899
# QnReZv5WtWwbD8HAFXbPPStW2JKCqPcZ54Y6wbuWV9bKtKPImqbkMcTejTgEAj82
# 6GQc6/Th66Koka8cUIvz59e/IP04DGrh9wkq2jIFvQ8EDegw1B4KyJTIs76+hmpV
# M5SwBZjRs3liOQrierkNVo11WuujB3kBf2CbPoP9MlOyyezqkMIbTRj4OHeKlamd
# WaSFhwHLJRIQpfc8sLwOSIBBAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhx/vdKmXhwc4WiWXbsf0I53h8T8w
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzUwMTgzNjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AGrJYDUS7s8o0yNprGXRXuAnRcHKxSjFmW4wclcUTYsQZkhnbMwthWM6cAYb/h2W
# 5GNKtlmj/y/CThe3y/o0EH2h+jwfU/9eJ0fK1ZO/2WD0xi777qU+a7l8KjMPdwjY
# 0tk9bYEGEZfYPRHy1AGPQVuZlG4i5ymJDsMrcIcqV8pxzsw/yk/O4y/nlOjHz4oV
# APU0br5t9tgD8E08GSDi3I6H57Ftod9w26h0MlQiOr10Xqhr5iPLS7SlQwj8HW37
# ybqsmjQpKhmWul6xiXSNGGm36GarHy4Q1egYlxhlUnk3ZKSr3QtWIo1GGL03hT57
# xzjL25fKiZQX/q+II8nuG5M0Qmjvl6Egltr4hZ3e3FQRzRHfLoNPq3ELpxbWdH8t
# Nuj0j/x9Crnfwbki8n57mJKI5JVWRWTSLmbTcDDLkTZlJLg9V1BIJwXGY3i2kR9i
# 5HsADL8YlW0gMWVSlKB1eiSlK6LmFi0rVH16dde+j5T/EaQtFz6qngN7d1lvO7uk
# 6rtX+MLKG4LDRsQgBTi6sIYiKntMjoYFHMPvI/OMUip5ljtLitVbkFGfagSqmbxK
# 7rJMhC8wiTzHanBg1Rrbff1niBbnFbbV4UDmYumjs1FIpFCazk6AADXxoKCo5TsO
# zSHqr9gHgGYQC2hMyX9MGLIpowYCURx3L7kUiGbOiMwaMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGgwwghoIAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAAOuLTVRyFOPVR0AAAAA
# A64wDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEdO
# tjI56DnF7S0e+fogHIrUXXFAiDiYW32W+I+7Bs9eMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEA079AfAihuvkWcpzMobF2yxT/sNRnc+tGTsWl
# J/FwjKjcfM3m73xcTmV/U3IYZgFnD6f2kigNch+ufDVULyJyEgfEOnjZRBNoI5RX
# Dso/twfkBthZvkEb8CU/9uy99O4PWZo9/0FhiG8oXhr8c5LU31jU5E5C6+n4BsKH
# rsrhZ+09bmeWEvGFXn3aDtAs3PLgWfy3bZWjRjcCbfR88hF+bMQ7u2/X3vC6GXIO
# GaX8bqiRMOaBVGSE1HYXqzN2X1UuLtbX8MLNYKGjph1ErmMKUrUAZY8VbPuCnkbq
# ZgJSiQcCSXZvn6/r9cIrCo73UdPQak7mkISyx6Q9yp/Nuzz1P6GCF5YwgheSBgor
# BgEEAYI3AwMBMYIXgjCCF34GCSqGSIb3DQEHAqCCF28wghdrAgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFRBgsqhkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCAPXdABRjSawbsNqSp3vFoNV5E7Ah4cVtAI
# +rYu859AmgIGZVbIiNLzGBIyMDIzMTIxMjA3NTc0NS4yMVowBIACAfSggdGkgc4w
# gcsxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsT
# HE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMxJzAlBgNVBAsTHm5TaGllbGQg
# VFNTIEVTTjpBOTM1LTAzRTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCEe0wggcgMIIFCKADAgECAhMzAAAB0bJbQChsLtJFAAEA
# AAHRMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTIzMDUyNTE5MTIxOFoXDTI0MDIwMTE5MTIxOFowgcsxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVy
# aWNhIE9wZXJhdGlvbnMxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjpBOTM1LTAz
# RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAJlM2jQ54bPZcV3aAuDmdOUG
# bxc6m7AkiJewxTrWvCrVkoOlrjjdGtIb+kfwbPpc2cVAoacKo0K2a+gpQsCnCtP+
# zv97VfSU0UqaPtTtfinTRLS5BtbovBKf/NYdobZznhlewZj4Fh+FYOBsWkJPFHNO
# dEIbrZuRY+npkdtk+Dge3UJEIAyGE4ZNHzAjgbvDBZnB0xzpS9RSWrSqX0DEB/OR
# hGmLa1G8Mcx2Zne/JemqEXC9EbxyAIf9NMKNbmrpo1t2oovcEUM/NS24I2w9cvf8
# TR1HZsMyprRo0f6Ih+EYLj+9zC6144wI9QgNVKoMI18ho8MTBhyLV932C7XNXD4c
# SENkzsRrefEhSvO35F+nlOgwyPhACYnpRp2b5M9sNujyQUgrvRKGZbzCfx8mT1F5
# BASlO0g3jd5G/1CZfLdR53zSiw4ET5aR0y9IIWH6qAKwp3NDFAkbrZxN6hTZ6o2E
# feimlebJ9VTBux59DMw+1uKcJl3QVSWaUz90f7g6eKpDJoe+u1jLfCohp9jfN4Uh
# OVUCg/2r28XhbsodH+4XSa9OkAvk1pMM3WmVBLQx2MySDNkrmC3Co57/etOWoHPH
# Brthine6s/nJaRPMhIaeE1Yhk7E7JAg7Fl9uIhsAdubczyGPvcpBZwJHklq+CTBS
# adwUcRJpB/gOuqz7/UvVAgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQUC47xTMXsNwfS
# aawXhdDHEdC9LaMwHwYDVR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYD
# VR0fBFgwVjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9j
# cmwvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwG
# CCsGAQUFBwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIw
# MjAxMCgxKS5jcnQwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcD
# CDAOBgNVHQ8BAf8EBAMCB4AwDQYJKoZIhvcNAQELBQADggIBAJu72tMAdXbiZjSq
# gbl4ScibPlqQZdO+IHAqnZjnWzbrDygOtaiv6bTRHj/cFwOZiVQrw2vH9q5gViJ1
# l11xSPDjZDFJK2a/+pacJCL/Y6cffYpUdD6Qw5k8AFBMbVeRydg9Q44QSivp//cm
# zW6PjCMfMThXhq6ZhcECyvgvkpHy8p6zm0XGEyRY0P87tb9FodjAkyMyTFWiwGiT
# tXbWwkCXFJwRfF8lr7+qSpSvsJmDDdHiMIdGQ+pCExaJtc8xhqv+IXRm4sH07z0M
# wk2GMr0FJ/qKqBmgy7MhW34QGhPOm//2njBDrGgEKzb2aSP8QhYV1z7lrfSS4JA5
# IQ6PTv5Yjb0DiTpAhEHnD54yZnQl5zSxLJ5AHkqPETnWJgyG2UytQpyvTqcGoKxI
# o9ixIAhMDOCywkP5n9xNLsK7fl8mtaEz01hfbi4DFgsBbSKk21am0h5XpqS5kR4R
# XoE20zdVOT6YCVXn94L/RjXtpVKMrn+DIOgs2auBXC/lMBoGar/CBFEUeZb1QnfO
# /wuaTqYigDJOmoFu5SMwvKu1qO5KwD+bYOcow7RCLPW/4VJVuozfwn89OWEJNRsU
# 7HSQtPtj/v5nKuKVULPIBh8UiKcMiNaUzzm0N5Txl8kKMUrCrcOxHFXgljXzHDDx
# NOah3eWSv02oZDngubI9Vz7mJs2uMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJ
# mQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNh
# dGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1
# WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjK
# NVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhg
# fWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJp
# rx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/d
# vI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka9
# 7aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKR
# Hh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9itu
# qBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyO
# ArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItb
# oKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6
# bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6t
# AgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQW
# BBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacb
# UzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYz
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnku
# aHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIA
# QwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2
# VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwu
# bWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYt
# MjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/q
# XBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6
# U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVt
# I1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis
# 9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTp
# kbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0
# sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138e
# W0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJ
# sWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7
# Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0
# dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQ
# tB1VM1izoXBm8qGCA1AwggI4AgEBMIH5oYHRpIHOMIHLMQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmlj
# YSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046QTkzNS0wM0Uw
# LUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoB
# ATAHBgUrDgMCGgMVAEcljYW/4aEtC1ENHa8jMFpK//ssoIGDMIGApH4wfDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQELBQACBQDpIjpDMCIY
# DzIwMjMxMjEyMDE0NzQ3WhgPMjAyMzEyMTMwMTQ3NDdaMHcwPQYKKwYBBAGEWQoE
# ATEvMC0wCgIFAOkiOkMCAQAwCgIBAAICGPoCAf8wBwIBAAICE34wCgIFAOkji8MC
# AQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEK
# MAgCAQACAwGGoDANBgkqhkiG9w0BAQsFAAOCAQEAWevLd/LHGecICaD1CwYqhcL/
# x6ITCxGwkWVWjUKUYVC1pvt+Z3PiLsUad9i52Gz9qHBgU5qtu3CJG5/fKQwzUwPg
# lGvNT0W5UY1VDFrsk8WYDIHnFW+3GW3SVVGAOb8hNa9BarArMP7VdLNGW2m8f8Wy
# UWSK/ocTHLQ8bHpD5O+KqOvhdqfJsX1sm0YbHIKkrsWtwigvLZH3lNBprD7kMQMi
# JpDcfiOErSJDDmqOtlBzbrJC3kdP5NgGbDsyaOFWrXyZ5T1f0SlMgfTivdE+/BM2
# GBMwGT3geV/g2pYXYOYmHtBDXAEZtPTvpmdtC19B6gupYZlW5RoKzv0YAPzAjjGC
# BA0wggQJAgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# 0bJbQChsLtJFAAEAAAHRMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMx
# DQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEIFE1QgYb+ARtmIbHDQjiXx0K
# jMzogkNFTJOG2HMX1aNVMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgzLxh
# eQIAu/ntzmxGGs9O5vWrhPAnqhUDfqTwiIj8BwwwgZgwgYCkfjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAdGyW0AobC7SRQABAAAB0TAiBCCTVV1Q
# sdjr4PmmicvCQGzKlNnnEZL2BwsaPPv2dc4ROzANBgkqhkiG9w0BAQsFAASCAgCI
# U2ie4qUxPcyi5AKUt4hfEXR2wV8gSLQ5SMamYApV6xKsQtniyp16mfdh3c6ek6LJ
# 4PjRRnc09BS2qEFWdZCT6mZKm9G0f6A4BHdUeh8OwDznmphFCbEmbxCTInzOfOMC
# oJzgcMH98rr6LgRdyz0i7SJCFowvgR3lDZEVCcDGjlUU0je+pyqK+ZlsJ9IhHTuG
# wATwiGVKLROoh3YVj8cSa4d2tFkXPWkMFz5ge86bXpNsB59+HJNyMa4TUcp5S467
# nttAjwJYR0nMG+8uzjnsh2kjzDHxUwbkmyW9xSGFEpSXC/mBf5/GRPhYLOF5wXju
# uW1TNgqRtyqhIF/CuRhJ9uYVEHQbg3ttmQ/mpAjUSUbvAo+muIFXhr7Nk7l/bJPa
# rEDcddMddl4MNnCDO3q7mtF+2yeXGUWAkmgNGj1nrhl72Xa5rAqRa/m3/4NATbBO
# 3EOlh+IIgzdXNcL0pH+vCh44vGESwcjsPaHDPg4iGeuKZaK5g2qrgvYZRcBwbwV6
# X1GrEocGim0+Mj2Yw3pp6xinDHbRo7/GOVLhJ53Y7zhpyDfIlcZ7rdKXRCpsdy17
# 70pqCU7xmLo0+sHawYE6vwZ2H9g8K+Xi4ZqwDzi7DZ07QdD4E2LVbGm3TIfDrMMP
# n8qZCa+S+hErHrpPsmlOq3g8krDqt1vUij7Ri2zFFw==
# SIG # End signature block
